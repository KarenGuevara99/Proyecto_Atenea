-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 11-11-2023 a las 02:20:47
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `php_mysql_crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `task`
--

DROP TABLE IF EXISTS `task`;
CREATE TABLE IF NOT EXISTS `task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `task`
--

INSERT INTO `task` (`id`, `title`, `description`, `created_at`) VALUES
(2, 'Dragon Ball Ultimate 1', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:16:58'),
(3, 'Dragon Ball, Vol. 3', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:17:30'),
(4, 'Dragon Ball Super no 13', 'Libro de Akira Toriyama y Toyotarō', '2023-11-11 02:17:49'),
(5, 'Dragon Ball ultimate 16', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:18:04'),
(6, 'Dragon Ball Super no 19', 'Libro\r\n', '2023-11-11 02:18:18'),
(7, 'Dragon Ball Ultimate no 14/34', 'Libro de Akira Toriyama', '2023-11-11 02:18:30'),
(8, 'Dragon Ball Super no 15', 'Libro de Akira Toriyama y Toyotarō', '2023-11-11 02:18:44'),
(9, 'Dragon Ball: Ilustraciones completas', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:18:59'),
(10, 'Dragon Ball Super no 06', 'Libro de Akira Toriyama y Toyotarō\r\n', '2023-11-11 02:19:14'),
(11, 'Dragon Ball Super no 10', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:19:31'),
(12, 'Dragon Ball Ultimate 2', 'Libro de Akira Toriyama\r\n', '2023-11-11 02:19:49'),
(13, '', '', '2023-11-11 02:19:55');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
