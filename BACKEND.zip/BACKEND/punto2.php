<!DOCTYPE html>
<html>
<head>
    <title>Verificación de Edad</title>
</head>
<body>
    <h1>Verificación de Edad</h1>
    <form method="post" action="">
        <label for="edad">Edad:</label>
        <input type="number" name="edad" required>
        <input type="submit" name="verificar" value="Verificar">
    </form>

    <?php
    if (isset($_POST['verificar'])) {
        $edad = $_POST['edad'];

        if ($edad < 18) {
            echo '<p>No es mayor de edad.</p>';
        } else {
            echo '<p>Es mayor de edad.</p>';
        }
    }
    ?>
</body>
</html>
