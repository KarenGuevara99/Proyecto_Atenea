$(window).on('load', function () {
    // Add YouTube thumbnail image
    $('#music tbody tr').addClass('list');
    $('.list').each(function () {
        var youtubeVideoId = $(this).attr('data-url');

        if (youtubeVideoId.length == 11) {
            var videoThumbnail = $('<img src="https://i.ytimg.com/vi/' + youtubeVideoId + '/hqdefault.jpg" class="img-responsive">');
            $(this).find('.thumb').append(videoThumbnail);
        }

        var rowNumber = $(this).index() + 1;
        $(this).find('td').eq(0).text(rowNumber);
    });

    // Select no of li
    var noOfLi = $('.list').length;
    var showNo = $('.show-row select').val();
    $('.show-row select').on('change', function (e) {
        showNo = $(this).val();
        myRemoveClass();
    });

    // Select function
    function myRemoveClass() {
        // Pagination
        var showNoOfLi = showNo;
        var showPage = Math.ceil(noOfLi / showNo);
        var counter;
        var no = 0;
        var start = no * showNoOfLi;
        var end = (no + 1) * showNoOfLi;

        $('.pagination').empty();

        for (counter = 1; counter <= showPage; counter++) {
            $('<li><a href="javascript:void(0)" data-lt="' + counter + '">' + counter + '</a></li>').appendTo('.pagination');
            $('.pagination li').eq(0).addClass('active');
        }

        $('#music tbody tr').removeClass('active-item').hide();
        $('#music tbody tr').slice(start, end).show().addClass('active-item');

        $('.prev').prop('disabled', true).parent('li').addClass('disabled');
        $('.next').prop('disabled', false).parent('li').removeClass('disabled');

        // Click on pagination
        function myFunction(controller) {
            return function () {
                if (controller == 'nextPagination') {
                    no++;
                } else if (controller == 'prevPagination') {
                    no--;
                } else if (controller == 'dots') {
                    $('.pagination li').removeClass('active');
                    var thisIndex = $(this).addClass('active').index();
                    no = thisIndex;
                }

                start = no * showNoOfLi;
                end = (no + 1) * showNoOfLi;

                $('#music tbody tr').removeClass('active-item').hide();
                $('#music tbody tr').slice(start, end).show().addClass('active-item');

                $('.prev').prop('disabled', no === 0).parent('li').toggleClass('disabled', no === 0);
                $('.next').prop('disabled', end >= noOfLi).parent('li').toggleClass('disabled', end >= noOfLi);
            };
        }

        $('.wrapper').on('click', '.next', myFunction('nextPagination'));
        $('.wrapper').on('click', '.prev', myFunction('prevPagination'));
        $('.wrapper').on('click', '.pagination li', myFunction('dots'));
    }

    myRemoveClass();

    // Live search box
    $('.search-row input').on('keyup', function () {
        var value = $(this).val();
        var patt = new RegExp(value, 'i');

        $('#music').find('.active-item').each(function () {
            if (!($(this).find('td').text().search(patt) >= 0)) {
                $(this).not('.myHead').hide();
            }

            if ($(this).find('td').text().search(patt) >= 0) {
                $(this).show();
            }
        });
    });
});
