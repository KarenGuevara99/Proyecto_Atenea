<!DOCTYPE html>
<html>
<head>
    <title>Verificación de Edad</title>
</head>
<body>
    <h1>Calculadora de Edad</h1>
    <form method="post" action="">
        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
        <input type="date" name="fecha_nacimiento" required>
        <input type="submit" name="calcular" value="Calcular">
    </form>

    <?php
    if (isset($_POST['calcular'])) {
        // Obtener la fecha de nacimiento del formulario
        $fecha_nacimiento = $_POST['fecha_nacimiento'];

        // Calcular la edad
        $fecha_actual = new DateTime();
        $fecha_nacimiento = new DateTime($fecha_nacimiento);
        $edad = $fecha_actual->diff($fecha_nacimiento)->y;

        // Mostrar el mensaje correspondiente
        echo "<p>Su edad es $edad años.</p>";
        if ($edad < 18) {
            echo "<p>No es mayor de edad.</p>";
        } else {
            echo "<p>Es mayor de edad.</p>";
        }
    }
    ?>
</body>
</html>
