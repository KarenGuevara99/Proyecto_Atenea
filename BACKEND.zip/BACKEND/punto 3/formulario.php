<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Datos</title>
</head>
<body>
    <h1>Ingrese sus datos:</h1>
    <form method="get" action="datos.php">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="apellido">Apellido:</label>
        <input type="text" name="apellido" required>

        <label for="cedula">Número de Cédula:</label>
        <input type="text" name="cedula" required>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
