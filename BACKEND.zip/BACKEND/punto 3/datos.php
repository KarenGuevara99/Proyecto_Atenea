<!DOCTYPE html>
<html>
<head>
    <title>Datos del Usuario</title>
</head>
<body>
    <h1>Datos del Usuario:</h1>

    <?php
    if (isset($_GET['nombre']) && isset($_GET['apellido']) && isset($_GET['cedula'])) {
        $nombre = $_GET['nombre'];
        $apellido = $_GET['apellido'];
        $cedula = $_GET['cedula'];

        echo "<p>Nombre: $nombre</p>";
        echo "<p>Apellido: $apellido</p>";
        echo "<p>Número de Cédula: $cedula</p>";
    } else {
        echo "<p>No se han proporcionado datos.</p>";
    }
    ?>
</body>
</html>
