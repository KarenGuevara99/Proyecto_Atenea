<!DOCTYPE html>
<html>
<head>
    <title>Calculadora</title>
</head>
<body>
    <h1>Calculadora</h1>
    <form method="post" action="">
        <label for="numero1">Número 1:</label>
        <input type="number" name="numero1" required>

        <label for="numero2">Número 2:</label>
        <input type="number" name="numero2" required>

        <label for="operacion">Operación:</label>
        <select name="operacion" required>
            <option value="SUMA">SUMA</option>
            <option value="RESTA">RESTA</option>
            <option value="MULTIPLICACION">MULTIPLICACIÓN</option>
            <option value="DIVISION">DIVISIÓN</option>
        </select>

        <input type="submit" name="calcular" value="Calcular">
    </form>

    <?php
    if (isset($_POST['calcular'])) {
        $numero1 = $_POST['numero1'];
        $numero2 = $_POST['numero2'];
        $operacion = $_POST['operacion'];
        $resultado = 0;

        switch ($operacion) {
            case 'SUMA':
                $resultado = $numero1 + $numero2;
                break;

            case 'RESTA':
                $resultado = $numero1 - $numero2;
                break;

            case 'MULTIPLICACION':
                $resultado = $numero1 * $numero2;
                break;

            case 'DIVISION':
                if ($numero2 != 0) {
                    $resultado = $numero1 / $numero2;
                } else {
                    echo '<p style="color:red;">No se puede dividir por cero.</p>';
                }
                break;

            default:
                echo '<p style="color:red;">Operación no válida.</p>';
                break;
        }

        echo '<p>Resultado: ' . $resultado . '</p>';
    }
    ?>
</body>
</html>
